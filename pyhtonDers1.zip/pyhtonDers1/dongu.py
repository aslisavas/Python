# -*- coding: utf-8 -*-
"""
Created on Thu Feb 21 10:15:42 2019

@author: student
"""
a=5
b=2
if b>a:
    print ("b buyuktur")
elif b==a:
    print("eşittir")
else:
    print("a buyuktur")
