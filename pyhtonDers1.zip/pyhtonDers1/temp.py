# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
x=2
y="veli"
print (x)
print (y)

print("merhaba",y)
print("merhaba"+y)

z=3
print(x+z)
print(str(x)+y)
t=3.5
w=2j+3
print(x+t)
print(w+x)
k=25262358789552554
print(k*x)
print(type(x))
print(type(y))
print(type(z))
print(type(w))
h=12e5 #e yi koyduğumuzda 10 üzeri 3 kadar büyük bir sayı"""
print(h)
x=1
y=2.8
z="3"
print(float(x)) #integer olan x i floata dönüştürdük
print(float(y))
print(int(z)) #string olan z yi inte çevirdik
print(str(x))
print(str(y))
print(str(z))
a="merhaba hüseyin" # 0 dan başladığı için 1.harf e oldu 
print(a[1])
print(a[1:3])
print(a[1:4:-1]) # 1 den başlayıp 4 e kadar 4 dahil değil tersten yazar
print(a.strip()) # boşlukları kaldırıyor
print(len(a)) #uzunluk ölçüyor
print(a.lower()) #tamamamını küçük harf olarak al demek 
print("AHMET".lower()) # benzer şekilde böylede kullanabiliriz
print(a.upper()) #tamamını büyük harf yapar
print(a.split(",")) #bölmek anlamına gelir.virgül gördüğü yerde ayır demek
print(a.split("e")) #her e gördüğün yerde ayır demek





