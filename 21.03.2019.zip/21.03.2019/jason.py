
# =============================================================================
# import json 
# #json notation
# x='{"isim":"huseyin","yas":30,"sehir":"Istanbul"}'
# #parse x:
# #y=json.loads(x)#json formatını dictinorye çevirdik.
# y=json.dumps(x)
# print(y)
# 
# import json 
# print(json.dumps({"isim":"huseyin","yas":30}))
# print(json.dumps(["elma","muz"]))
# print(json.dumps(("elma","muz")))
# print(json.dumps("Merhaba"))
# print(json.dumps(45))
# print(json.dumps(24.7))
# print(json.dumps(True))
# print(json.dumps(False))
# print(json.dumps(None))
# 
# import json 
# x={
#    "isim":"huseyin",
#    "yas":30,
#    "sehir":"Istanbul",
#    "medeni":"Bekar",
#    "askerlik":False,
#    "kardes":("ahemt","damla"),
#    "evcil":None,
#    "araba":[{"marka":"BMW","Renk":"siyah"},
#             {"marka":"Mazda","Renk":"Beyaz"}]
#    
#   }
# print(json.dumps(x,indent=4,separators=(".","=")))#indenet girinti veya boşluk ,seperators ayraç bölücü demek,sort_keys=True A-Z ye sıralar
# =============================================================================
