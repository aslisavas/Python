"""
import json 
print(json.dumps({"isim":"huseyin","yas":30}))
print(json.dumps(["elma","muz"]))
print(json.dumps(("elma","muz")))
print(json.dumps("Merhaba"))
print(json.dumps(45))
print(json.dumps(24.7))
print(json.dumps(True))
print(json.dumps(False))
print(json.dumps(None))

import json 
x={
   "isim":"huseyin",
   "yas":30,
   "sehir":"Istanbul",
   "medeni":"Bekar",
   "askerlik":False,
   "kardes":("ahemt","damla"),
   "evcil":None,
   "araba":[{"marka":"BMW","Renk":"siyah"},
            {"marka":"Mazda","Renk":"Beyaz"}]
   
  }
print(json.dumps(x,indent=4,separators=(".","=")))#indenet girinti veya boşluk ,seperators ayraç bölücü demek,sort_keys=True A-Z ye sıralar
"""
#Regex --->Regular Expression,düzenli ifade
import re
test="3 kahveniz 7 liradan kallavi "
#^ şapka işareti koyduğumuz zaman cumlenin başından başla deriz.$dolar koyduğumuz zaman cümlenin sonuna bakıyor.
#x=re.search("hava",test)
# =============================================================================
#y=re.findall("al*",test)
#re.findall("al+",test)
# x=re.findall("[a-h]",test) #a ile h arasında kiler var
# x=re.findall("al{2}",test)#a dan sonra sadece iki l olanları getir.cümledeki all ları getirir.
# x=re.findall("[aln]",test)#köşeli parantez kullandığımız için karakter olarak algılıyor cümle de ki a l ve n leri getirir.
# x=re.findall("[^aln]",test)#tam tersi olmayanları getirir.
# x=re.findall("[0-5][0-9]",test)#onlar basamağı 5 arası birler basamağı 09 arası olan sayıları getirir yani 0 dan 59 a kadar olan sayıları getirir.
# x=re.findall("[a-zA-Z0-90_]",test)#mail şife kontrol
# x=re.findall("\d",test)
#x=re.findall("\D",test)
# =============================================================================
x=re.sub("\s","z",test)#spacein yerine z koyduk
print(x)
if(x):
    print("sözcük var")
else:
    print("sözcük yoktur")