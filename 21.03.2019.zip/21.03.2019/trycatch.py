#try catch
# =============================================================================
# try:
#     print(z)
# except NameError:
#     print("degisken tanımlı değil")
# except:
#     print("baska hata var")
# else:
#     print("hata yok")
# finally:#hata olsa bile çalışan blok
#     print("hata yok")
# 
# =============================================================================
# =============================================================================
# import random
# import re
# try:
#     dizi=["a","b","c","d","f","g",",",".","0","2","3","4","5","6","7","8","9","_"]
#     uz=len(dizi)
#     dizi2=[]
#     for j in range(10): 
#         y=""
#         for x in range(8):
#             i=random.randint(0,uz-1)
#             y+=dizi[i]
#         print(y)
#         dizi2.append(y)
#     print(dizi2[j])
#     w=dizi2[0]
#     ss=re.sub(".","_",w)
#     print(ss)
#     if re.findall("[0-9]",ss[0]):
#         print("sifre OK")
#         zz=re.sub(ss[0],"_",ss)
#     print(zz)
#     
#         
#     print(w)
# except:
#     print ("baska hata var")
# finally:
#     print("hata yok")
# =============================================================================
    



    